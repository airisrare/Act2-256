@extends('layouts.appmaster')
@section('title', 'Login Passed')

@section('content')
<h2>Welcome to our website</h2>

@if($model->getUsername() == 'patrick')
    <h3>Patrick you have logged in successfully.</h3>
    @else
        <h3>You arent patrick.</h3>
        @endif
        
        <input type="submit" formaction="login2" class="btn btn-primary" value="login2">
        @endsection
        