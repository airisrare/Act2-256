<?php
namespace App\Services\Data;

use App\Models\UserModel;
use Carbon\Exceptions\Exception;

class SecurityDAO
{
    //define connection
    private $conn;
    private $servername = "localhost";
    private $username = "root";
    private $password = "root";
    private $dbname = "activity2";
    private $dbQuery;
    private $port = "3306";
    
    //constructor that creates a coonnection with the database
    public function __construct()
    {
        //create a connection to the database
        $this->conn = mysqli_connect($this->servername, $this->username, $this->password ,$this->dbname, $this->port);
                //make sure to test the connection to see if there are any errors
    }
    
    //method to verify user credentials
    function FindByUserName(UserModel $credentials)
    {
        try {
            // define the query and DB
            $this->dbQuery = " SELECT username, password FROM users WHERE username = '{$credentials->getUsername()}' AND password = '{$credentials->getPassword()}' ";
            
            $result = mysqli_query($this->conn, $this->dbQuery);
            
            if (mysqli_num_rows($result) > 0) {
                mysqli_free_result($result);
                mysqli_close($this->conn);
                return true;
            } else {
                mysqli_free_result($result);
                mysqli_close($this->conn);
                return false;
            }
        } catch (Exception $e) {
            $e->getMessage();
        }
    }

}
    


