<?php
namespace App\Models;

class UserModel
{
    //private variables
    private $username;
    private $password;
     
    //constructor
    public function __construct($username,$password)
    {
        $this->username = $username;
        $this->password = $password;
    }
    
    
    //Getter method for username
    
    /**
     * @return mixed
     * @return string
     */
    public function getUsername()
    {
        return $this->username;
    }

    /**
     *     //Getter method for password
     *     @return string
     */
    public function getPassword()
    {
        return $this->password;
    }


}

